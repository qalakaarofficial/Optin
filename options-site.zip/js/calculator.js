function calculate() {
  const type = document.getElementById("optionType").value;
  const strike = parseFloat(document.getElementById("strikePrice").value);
  const premium = parseFloat(document.getElementById("premium").value);
  const expiryPrice = parseFloat(document.getElementById("expiryPrice").value);
  let result = 0;

  if (type === "call") {
    result = Math.max(0, expiryPrice - strike) - premium;
  } else {
    result = Math.max(0, strike - expiryPrice) - premium;
  }

  document.getElementById("result").innerHTML = "<p>Profit/Loss per share: $" + result.toFixed(2) + "</p><p>Total (×100): $" + (result * 100).toFixed(2) + "</p>";
}